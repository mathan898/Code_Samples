

let mysql = require('mysql');
var CloudmersiveConvertApiClient = require('cloudmersive-convert-api-client');
var defaultClient = CloudmersiveConvertApiClient.ApiClient.instance;
var apiInstance = new CloudmersiveConvertApiClient.ValidateDocumentApi();
// Apikey.apiKey = 'YOUR API KEY';
// Apikey.apiKeyPrefix = 'Token';

let connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Enter321',
  database: 'fileUpload',
  port: 3307
});

connection.connect(function (err) {
  if (err) {
    return console.error('error: ' + err.message);
  }

  console.log('Connected to the MySQL server.');
});

const express = require('express');
const multer = require('multer');
const { Console } = require('console');
const upload = multer({
  dest: 'uploads/' // this saves your file into a directory called "uploads"
});

const app = express();

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// function checking(text) {
//   try {
//       libxmljs.parseXml(text);
//   } catch (e) {
//       console.log(e);
//       console.log("Failed to validate the XML");
//       return false;
//   }
//   console.log("Success to validate the XML");
//   return true;
// };

var callback = function (error, data, response) {
  console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
  if (error) {
    console.error(error + "$$$$$$$$$$$$$$$$$");
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};


app.post('/', upload.single('file-to-upload'), (req, res) => {
  console.log(req.file);
  if (req.file != null) {
    apiInstance.validateDocumentXmlValidation(req.file.filename, callback);
    var filenamesplit = req.file.originalname;
    var filename = filenamesplit.substring(0, filenamesplit.lastIndexOf("."));
    var filetype = filenamesplit.substring(filenamesplit.lastIndexOf(".") + 1, filenamesplit.length);
    var querystr = "INSERT INTO fileUpload.file_info (fileid, filename, filetype, filesize, Sourcefile) VALUES ('" + 0 + "','" + filename + "','" + filetype + "','" + req.file.size + "','" + req.file.filename + "')";
    console.log(querystr);
    connection.query(querystr, (err, rows, fields) => {
      if (!err) {
        res.send(rows);
      } else {
        console.log(err);
      }
    })
    res.sendFile(__dirname + '/uploded.html');
  } else {
    res.sendFile(__dirname + '/pagenotfound.html');
  }
});

app.listen(3000);